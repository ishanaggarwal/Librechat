const checkAdmin = require('./checkAdmin');
const generateCheckAccess = require('./generateCheckAccess');

module.exports = {
  checkAdmin,
  generateCheckAccess,
};
