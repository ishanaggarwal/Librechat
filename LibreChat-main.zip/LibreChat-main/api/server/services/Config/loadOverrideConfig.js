// fetch some remote config
async function loadOverrideConfig() {
  return false;
}

module.exports = loadOverrideConfig;
