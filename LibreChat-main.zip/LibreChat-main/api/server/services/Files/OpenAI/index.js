const crud = require('./crud');

module.exports = {
  ...crud,
};
