const createStartHandler = require('./createStartHandler');

module.exports = {
  createStartHandler,
};
